import React, { Component } from 'react'
import PanelHeader from "components/PanelHeader/PanelHeader.jsx";
import { Card, CardBody, Row, Col, CardTitle, CardHeader, Input, Button, FormGroup, Label } from 'reactstrap'
import { BEARER, ACCESS_TOKEN } from '../Constants/APIConstant'
import DataTable from 'react-data-table-component'
import axios from 'axios-auth';

class QuestionList extends Component {
  constructor(props) {
    super(props);
    axios.defaults.headers.common['Authorization'] = BEARER + window.localStorage.getItem(ACCESS_TOKEN);
    this.state = {
      questionList: [],
      totalRows: null,
      currentpage: 0,
      rowsPerPage: 10,
    }
  }
  componentDidMount() {
    this.loadQuestionList(this.state.currentpage, this.state.rowsPerPage);
  }
  loadQuestionList(pageNo, pageSize) {
    debugger;
    axios.get("/question", {
      params: {
        pageNo: pageNo,
        pageSize: pageSize
      }
    }).then(res => {
      debugger;
      this.setState({ questionList: res.data.content, totalRows: res.data.totalElements, currentpage: res.data.pageable.pageNumber })
    }).catch(error => {
      console.log(error);
    });
  }
  handlePerRowsChange = (newPerPage, page) => {
    debugger;
    this.setState({ rowsPerPage: newPerPage })
    this.loadQuestionList(page - 1, newPerPage);
  };
  handlePageChange = page => {
    debugger;
    this.loadQuestionList(page - 1, this.state.rowsPerPage);
  };
  deleteHandler = (id) => {
    axios.delete("/question/" + id + "").then(res => {
      if (res) {
        this.loadExamlist(this.state.currentpage, this.state.rowsPerPage);
      }
    })
  }
  render() {
    const columns = [
      {
        name: 'Question',
        selector: 'question',
        sortable: true,
        width: '200px',
        minHeight: '60px'
      },
      {
        name: 'Category',
        selector: 'ansCategory',
        sortable: true
      },
      {
        name: 'Option1',
        selector: 'option1',
        sortable: true
      },
      {
        name: 'Option2',
        selector: 'option2',
        sortable: true
      },
      {
        name: 'Option3',
        selector: 'option3',
        sortable: true
      },
      {
        name: 'Option4',
        selector: 'option4',
        sortable: true
      },
      {
        name: 'Action',
        cell: row => {
          debugger
          return (
            <React.Fragment>
              <img src={require("assets/icons/edit-button.svg")} style={{ "width": "22px", "heigth": "22px", "cursor": "pointer" }} onClick={() => this.editExamhamdler(row)}></img>
              <img src={require("assets/icons/trash-outline.svg")} style={{ "width": "22px", "heigth": "22px", "cursor": "pointer" }} onClick={() => this.deleteHandler(row.id)} disables="true"></img>
            </React.Fragment>
          )
        }
      }
    ];
    const customStyles = {
      rows: {
        style: {
          minHeight: '60px', // override the row height
        }
      },
      headCells: {
        style: {
          paddingLeft: '5px', // override the cell padding for head cells
          paddingRight: '5px',
        },
      },
      cells: {
        style: {
          paddingLeft: '3px', // override the cell padding for data cells
          paddingRight: '1px',
        },
      },
    };
    return (
      <>
        <PanelHeader size="sm" />
        <div className="content">
          <Row>
            <Col>
              <Card>
                <CardBody>
                  <CardHeader>Question List</CardHeader>
                  <CardBody>
                    <Row>
                      <Col md="3">
                        <Input type="text" placeholder="Search"></Input>
                      </Col>
                      <Col md="3">
                        <button className="primary" style={{ "backgroundColor": "transparent" }}>Add Question</button>
                      </Col>
                    </Row>
                  </CardBody>
                  <DataTable
                    columns={columns}
                    data={this.state.questionList}
                    pagination={true}
                    customStyles={customStyles}
                    keyField="id"
                    paginationServer={true}
                    paginationTotalRows={this.state.totalRows}
                    paginationDefaultPage={this.state.currentpage + 1}
                    onChangeRowsPerPage={this.handlePerRowsChange}
                    onChangePage={this.handlePageChange}
                  />
                </CardBody>
              </Card>
            </Col>
          </Row>
        </div>
      </>
    )
  }
}

export default QuestionList