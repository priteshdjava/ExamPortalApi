import React, { Component } from 'react'
import PerfectScrollbar from "perfect-scrollbar";
import axios from 'axios-auth'
import withErrorHandler from 'hoc/withErrorHandler/withErrorHandler'
import AdminSidebar from "components/Sidebar/AdminSidebar";
import Footer from "components/Footer/Footer.jsx";
import DemoNavbar from "components/Navbars/DemoNavbar.jsx";
import userRoutes from "adminRoutes";
import PanelHeader from "components/PanelHeader/PanelHeader.jsx";
import Datepicker from 'reactstrap-date-picker';
import {
  Card,
  CardBody,
  CardTitle,
  Button, Form, FormGroup, Label, Input, FormText, Col, Row
} from "reactstrap";

var ps;
class AddUserPage extends Component {
  constructor(props) {
    debugger;
    super(props);
    this.state = {
      backgroundColor: "blue",
      user: {},
      profileImage: null,
      profilePicture: {},
      newUser: false,
      title: ""
    }
  }
  mainPanel = React.createRef();
  componentDidMount() {
    debugger;
    if (navigator.platform.indexOf("Win") > -1) {
      ps = new PerfectScrollbar(this.mainPanel.current);
      document.body.classList.toggle("perfect-scrollbar-on");
    }
    if (typeof this.props.location.state !== "undefined") {
      if (null !== this.props.location.state.profileImageUrl) {
        debugger;
        axios.get("/user" + this.props.location.state.profileImageUrl + "").then(response => {
          debugger;
          if (typeof response === "undefined") {
            this.setState({ profilePicture: require("assets/img/avatar.png") })
          } else {
            this.setState({ profilePicture: response.data })
          }
        })
      }
      this.setState({ user: this.props.location.state, title: "Edit User" })
    } else {
      this.setState({ profilePicture: require("assets/img/avatar.png"), newUser: true, title: "Add User" })
    }

  }

  componentDidUpdate(e) {
    debugger;
    if (e.history.action === "PUSH") {
      this.mainPanel.current.scrollTop = 0;
      document.scrollingElement.scrollTop = 0;
    }
  }
  handleColorClick = color => {
    debugger;
    this.setState({ backgroundColor: color });
  };

  imputChangeHandler = (event) => {
    debugger;
    const updatedUser = {
      ...this.state.user,
      [event.target.name]: event.target.value
    }
    this.setState({ user: updatedUser })
  }
  formSubmitHandler = (event) => {
    event.preventDefault();
    debugger;
    const date = document.getElementById("dob").dataset.formattedvalue;
    const updatedUser = {
      ...this.state.user,
      dob: date
    }
    if (this.state.newUser) {
      debugger;
      axios.post("/user/admin", updatedUser).then(res => {
        debugger;
        if (res && res.status === 200) {
          debugger;
          const formData = new FormData();
          formData.append("file", this.state.profileImage);
          formData.append("userId", res.data.id);
          axios.post("/user/profile/upload", formData).then(res => {
            debugger;
            console.log(res);
            this.props.history.push("/admin/user-list")
          });
        }
        //this.props.history.push("/user/user-page")
      })
    } else {
      axios.put("/user", updatedUser).then(res => {
        debugger;
        if (res && res.status === 200) {
          debugger;
          const formData = new FormData();
          formData.append("file", this.state.profileImage);
          formData.append("userId", updatedUser.id);
          axios.post("/user/profile/upload", formData).then(res => {
            debugger;
            console.log(res);
            this.props.history.push("/admin/user-list")
          });
        }
        //this.props.history.push("/user/user-page")
      })
    }
  }
  fileClickHandler = (fileId) => {
    var elem = document.getElementById(fileId);
    if (elem && document.createEvent) {
      var evt = document.createEvent("MouseEvents");
      evt.initEvent("click", true, false);
      elem.dispatchEvent(evt);
    }
  }
  fileChangeHandler = (event) => {
    debugger;
    console.log(event.target.files[0]);
    this.setState({ profileImage: event.target.files[0] })
    document.getElementById("photo").src = URL.createObjectURL(event.target.files[0])
  }
  fileClickHandler = (fileId) => {
    var elem = document.getElementById(fileId);
    if (elem && document.createEvent) {
      var evt = document.createEvent("MouseEvents");
      evt.initEvent("click", true, false);
      elem.dispatchEvent(evt);
    }
  }
  render() {
    debugger;
    let options = [];
    let roleOption = [];
    if (this.state.user.gender === "Male") {
      let option = (
        <React.Fragment>
          <option>Select Gender</option>
          <option value="Male" selected>Male</option>
          <option value="Female">Female</option>
        </React.Fragment>
      );
      options.push(option);
    } else if (this.state.user.gender === "Female") {
      let option = (
        <React.Fragment>
          <option>Select Gender</option>
          <option value="Male">Male</option>
          <option value="Female" selected>Female</option>
        </React.Fragment>
      );
      options.push(option);
    } else {
      let option = (
        <React.Fragment>
          <option>Select Gender</option>
          <option value="Male">Male</option>
          <option value="Female">Female</option>
        </React.Fragment>
      );
      options.push(option);
    }

    if (this.state.user.role === "Admin") {
      let option = (
        <React.Fragment>
          <option>Select Role</option>
          <option value="Admin" selected>Admin</option>
          <option value="User">User</option>
        </React.Fragment>
      );
      roleOption.push(option);
    } else if (this.state.user.role === "User") {
      let option = (
        <React.Fragment>
          <option>Select Role</option>
          <option value="Admin">Admin</option>
          <option value="User" selected>User</option>
        </React.Fragment>
      );
      roleOption.push(option);
    } else {
      let option = (
        <React.Fragment>
          <option>Select Role</option>
          <option value="Admin">Admin</option>
          <option value="User">User</option>
        </React.Fragment>
      );
      roleOption.push(option);
    }
    return (
      <div className="wrapper">
        <AdminSidebar
          {...this.props}
          routes={userRoutes}
          backgroundColor={this.state.backgroundColor}
        />
        <div className="main-panel" ref={this.mainPanel}>
          <DemoNavbar {...this.props} />
          <>
            <PanelHeader size="lg" />
            <div className="content">

              <div>
                <Card body className="text-center">
                  <CardBody>
                    <CardTitle>{this.state.title}</CardTitle>

                    <Form center="true">
                      <Col md="3">
                        <Card className="card-user">
                          <div className="image">
                            <img alt="..." src={require("assets/img/bg5.jpg")} />
                          </div>
                          <div className="author">
                            {/* <img alt="..." src={require("assets/img/bg5.jpg")} onClick={() => this.fileClickHandler("file")} style={{ "cursor": "pointer" }} /> */}
                            <img
                              id="photo"
                              alt="..."
                              className="avatar border-gray"
                              src={this.state.profilePicture}
                              style={{ "cursor": "pointer" }}
                              onClick={() => this.fileClickHandler("file")}
                            />
                          </div>
                        </Card>
                      </Col>
                      <Row>
                        <Col inline>
                          <FormGroup inline>
                            <Label>First Name</Label>
                          </FormGroup>
                        </Col>
                        <Col inline>
                          <FormGroup inline>
                            <Input type="text" name="firstName" value={this.state.user.firstName} onChange={(event) => this.imputChangeHandler(event)} />
                          </FormGroup>
                        </Col>
                        <Col inline>
                          <FormGroup inline>
                            <Label>Last Name</Label>
                          </FormGroup>
                        </Col>
                        <Col inline>
                          <FormGroup inline>
                            <Input type="text" name="lastName" value={this.state.user.lastName} onChange={(event) => this.imputChangeHandler(event)} />
                          </FormGroup>
                        </Col>
                      </Row>

                      <Row>
                        <Col inline>
                          <FormGroup inline>
                            <Label>Gender</Label>
                          </FormGroup>
                        </Col>
                        <Col inline>
                          <FormGroup inline>
                            <Input type="select" name="select" id="exampleSelect" name="gender" onChange={(event) => this.imputChangeHandler(event)}>
                              {options}
                            </Input>
                          </FormGroup>
                        </Col>
                        <Col inline>
                          <FormGroup inline>
                            <Label>Date Of Birth</Label>
                          </FormGroup>
                        </Col>
                        <Col inline>
                          <FormGroup inline>
                            <Datepicker id="dob" name="dob" dateFormat="YYYY-MM-DD" value={this.state.user.dob} />
                          </FormGroup>
                          <Input type="file" id="file" hidden onChange={(event) => this.fileChangeHandler(event)} />
                        </Col>
                      </Row>
                      <Row>
                        <Col inline>
                          <FormGroup inline>
                            <Label>Role</Label>
                          </FormGroup>
                        </Col>
                        <Col inline>
                          <FormGroup inline>
                            <Input type="select" name="select" id="exampleSelect" name="role" onChange={(event) => this.imputChangeHandler(event)}>
                              {roleOption}
                            </Input>
                          </FormGroup>
                        </Col>
                        {
                          this.state.newUser ?
                            (
                              <React.Fragment>
                                <Col inline>
                                  <FormGroup inline>
                                    <Label>Password</Label>
                                  </FormGroup>
                                </Col>
                                <Col inline>
                                  <FormGroup inline>
                                    <Input type="password" name="password" onChange={(event) => this.imputChangeHandler(event)} />
                                  </FormGroup>
                                </Col>
                              </React.Fragment>
                            )
                            : ""
                        }
                      </Row>
                      <Row>
                        {
                          this.state.newUser ?
                            (
                              <React.Fragment>
                                <Col inline>
                                  <FormGroup inline>
                                    <Label>Email</Label>
                                  </FormGroup>
                                </Col>
                                <Col inline>
                                  <FormGroup inline>
                                    <Input type="text" name="email" onChange={(event) => this.imputChangeHandler(event)} />
                                  </FormGroup>
                                </Col>
                              </React.Fragment>
                            )
                            : ""
                        }
                      </Row>
                    </Form>
                    <Button onClick={(event) => this.formSubmitHandler(event)} color="primary">Submit</Button>
                  </CardBody>
                </Card>
              </div>
            </div>
          </>
          <Footer fluid />
        </div>
      </div>

    )
  }
}

export default withErrorHandler(AddUserPage, axios)