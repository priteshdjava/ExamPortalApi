import React from "react";
// react plugin used to create charts
//import { Line, Bar } from "react-chartjs-2";

// reactstrap components
import { Card, CardBody,CardTitle} from "reactstrap";

// core components
import PanelHeader from "components/PanelHeader/PanelHeader.jsx";

//import { dashboardPanelChart} from "variables/charts.jsx";

class UserDashboard extends React.Component {
  render() {
    return (
      <>
        <PanelHeader size="lg"/>
        <div className="content">
        <div>
      <Card body className="text-center">
        <CardBody>
          <CardTitle><h1>Hello,Pritesh</h1></CardTitle>

        </CardBody>
      </Card>
    </div>
        </div>
      </>
    );
  }
}

export default UserDashboard;
