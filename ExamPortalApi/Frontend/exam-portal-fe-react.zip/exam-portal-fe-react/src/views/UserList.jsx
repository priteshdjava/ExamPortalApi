import React, { Component } from 'react'
import PanelHeader from "components/PanelHeader/PanelHeader.jsx";
import { Card, CardBody, CardTitle } from "reactstrap";
import { BEARER, ACCESS_TOKEN } from '../Constants/APIConstant'
import axios from 'axios-auth';
import DataTable, { createTheme } from 'react-data-table-component'
import { Input, Button } from 'reactstrap'


class UserList extends Component {

  constructor(props) {
    debugger;
    super(props);
    axios.defaults.headers.common['Authorization'] = BEARER + window.localStorage.getItem(ACCESS_TOKEN);
    this.state = {
      userList: [],
      totalRows: null,
      currentpage: 0,
      rowsPerPage: 10
    }

  }
  componentDidMount() {
    debugger;
    this.fetchUserList(this.state.currentpage, this.state.rowsPerPage);
  }
  fetchUserList(pageNo, pageSize) {
    debugger;
    axios.get("/user/findAll", {
      params: {
        pageNo: pageNo,
        pageSize: pageSize
      }
    }).then(res => {
      debugger;
      this.setState({ userList: res.data.content, totalRows: res.data.totalElements, currentpage: res.data.pageable.pageNumber })
    }).catch(error => {
      console.log(error);
    });
  }
  deleteHandler = (id) => {
    const deleteId = id;
    axios.get("/user/find").then(res => {
      debugger;
      if (res && res.data.id !== id) {
        debugger;
        axios.delete("/user/" + id + "").then(res => {
          debugger;
          if (res.status === 200) {
            this.fetchUserList(this.state.currentpage, this.state.rowsPerPage);
          }
        })
      }
    }).catch(error => {
      console.log(error);
    })
    console.log(id);
  }

  editUserHandler = (userObj) => {
    this.props.history.push({
      pathname: '/admin/edit',
      state: {
        ...userObj
      }
    })
  }
  addNewUserHandler = () => {
    this.props.history.push({
      pathname: '/admin/edit'
    })
  }
  searchHandler = (event) => {
    debugger;
    axios.get("/user/search/", {
      params: {
        searchText: event.target.value
      }
    }).then(res => {
      debugger;
      if (res && res.status === 200) {
        this.setState({ userList: res.data.content, totalRows: res.data.totalElements, currentpage: res.data.pageable.pageNumber })
      }
    })
  }
  handlePerRowsChange = (newPerPage, page) => {
    debugger;
    this.setState({ rowsPerPage: newPerPage })
    this.fetchUserList(page - 1, newPerPage);
  };
  handlePageChange = page => {
    debugger;
    this.fetchUserList(page - 1, this.state.rowsPerPage);
  };
  render() {
    const columns = [
      {
        name: 'First Name',
        selector: 'firstName',
        sortable: true
      },
      {
        name: 'Last Name',
        selector: 'lastName',
        sortable: true
      },
      {
        name: 'Email',
        selector: 'email',
        sortable: true,
      },
      {
        name: 'Dob',
        selector: 'dob',
        sortable: true,
      },
      {
        name: 'Action',
        cell: row => {
          debugger
          return (
            <React.Fragment>
              <img src={require("assets/icons/edit-button.svg")} style={{ "width": "22px", "heigth": "22px", "cursor": "pointer" }} onClick={() => this.editUserHandler(row)}></img>
              <img src={require("assets/icons/trash-outline.svg")} style={{ "width": "22px", "heigth": "22px", "cursor": "pointer" }} onClick={() => this.deleteHandler(row.id)} disables="true"></img>
            </React.Fragment>
          )
        }
      }
    ]

    const customStyles = {
      rows: {
        style: {
          minHeight: '40px', // override the row height
        }
      },
      headCells: {
        style: {
          paddingLeft: '5px', // override the cell padding for head cells
          paddingRight: '5px',
        },
      },
      cells: {
        style: {
          paddingLeft: '1px', // override the cell padding for data cells
          paddingRight: '1px',
        },
      },
    };
    const conditionalRowStyles = [
      {
        when: row => row.calories < 300,
        style: {
          backgroundColor: 'green',
          color: 'white',
          '&:hover': {
            cursor: 'pointer',
          },
        },
      },
    ];

    return (
      <>
        <PanelHeader size="sm" />
        <div className="content">

          <Card body className="text-center">
            <div>
              <Input type="text" placeholder="Search" style={{ "float": "left", "width": "20%" }} onChange={(event) => this.searchHandler(event)} />
            </div>
            <div>
              <Button style={{ "float": "right" }} color="success" onClick={this.addNewUserHandler}>Add User</Button>
            </div>
            <CardBody>

              <DataTable
                columns={columns}
                data={this.state.userList}
                pagination={true}
                customStyles={customStyles}
                conditionalRowStyles={conditionalRowStyles}
                keyField="id"
                paginationServer={true}
                paginationTotalRows={this.state.totalRows}
                paginationDefaultPage={this.state.currentpage + 1}
                onChangeRowsPerPage={this.handlePerRowsChange}
                onChangePage={this.handlePageChange}
              />
            </CardBody>
          </Card>
        </div>
      </>
    )
  }
}

export default UserList;