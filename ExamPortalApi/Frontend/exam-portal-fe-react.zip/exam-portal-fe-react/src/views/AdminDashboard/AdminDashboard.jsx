import React from "react";
// react plugin used to create charts
import { Line, Bar } from "react-chartjs-2";
import { translate } from 'react-i18next';

// reactstrap components
import {
  Card,
  CardBody,
  CardTitle
} from "reactstrap";

// core components
import PanelHeader from "components/PanelHeader/PanelHeader.jsx";
class AdminDashboard extends React.Component {
  render() {
    const { t } = this.props;
    return (
      <>
        <PanelHeader size="lg" />
        <div className="content">
          <div>
            <Card body className="text-center">
              <CardBody>
                <CardTitle><h1>{t('AdminDashboard.title')}</h1></CardTitle>

              </CardBody>
            </Card>
          </div>
        </div>
      </>
    );
  }
}

export default translate('common')(AdminDashboard);
