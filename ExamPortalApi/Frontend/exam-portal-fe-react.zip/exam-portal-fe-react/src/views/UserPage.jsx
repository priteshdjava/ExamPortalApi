import React from "react";
import axios from 'axios-auth';
import withErrorHandler from 'hoc/withErrorHandler/withErrorHandler'
import Datepicker from 'reactstrap-date-picker';
import '../assets/css/userPage.css'
// reactstrap components
import {
  Button,
  Card,
  CardHeader,
  CardBody,
  FormGroup,
  Form,
  Input,
  Row,
  Col,
  Label,
  Tooltip
} from "reactstrap";

// core components
import PanelHeader from "components/PanelHeader/PanelHeader.jsx";

class User extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      user: {},
      profilePicture: {},
      tooltipOpen: false,
      editable: false,
      profileImage: null,
      file: null
    }
  }

  toggle = () => this.setState({ tooltipOpen: !this.state.tooltipOpen })
  componentDidMount() {
    this.loadData();
  }

  loadData() {
    debugger;
    axios.get("/user/find").then(res => {
      debugger;
      if (res) {
        if (res.data.profileImageUrl != null) {
          axios.get("/user" + res.data.profileImageUrl + "").then(res => {
            debugger;
            if (typeof res === "undefined") {
              this.setState({ profilePicture: require("assets/img/avatar.png") })
            } else {
              this.setState({ profilePicture: res.data })
            }
          });
          this.setState({ user: res.data, editable: false });
        } else {
          this.setState({ profilePicture: require("assets/img/avatar.png"), user: res.data, editable: false })
        }
      }
    });
  }
  onEditHandler = (event) => {
    debugger;
    event.preventDefault();
    this.setState({ editable: true })
  }

  imputChangeHandler = (event) => {
    debugger;
    const updatedUser = {
      ...this.state.user,
      [event.target.name]: event.target.value
    }
    this.setState({ user: updatedUser })
  }
  fileChangeHandler = (event) => {
    debugger;
    console.log(event.target.files[0]);
    this.setState({ profileImage: event.target.files[0] })
    document.getElementById("photo").src = URL.createObjectURL(event.target.files[0])
  }
  fileClickHandler = (fileId) => {
    var elem = document.getElementById(fileId);
    if (elem && document.createEvent) {
      var evt = document.createEvent("MouseEvents");
      evt.initEvent("click", true, false);
      elem.dispatchEvent(evt);
    }
  }
  formSubmitHandler = (event) => {
    event.preventDefault();
    debugger;
    const date = document.getElementById("dob").dataset.formattedvalue;
    const updatedUser = {
      ...this.state.user,
      dob: date
    }
    axios.put("/user", updatedUser).then(res => {
      debugger;
      if (res && res.status === 200) {
        debugger;
        const formData = new FormData();
        formData.append("file", this.state.profileImage);
        formData.append("userId", window.localStorage.getItem("userId"));
        axios.post("/user/profile/upload", formData).then(res => {
          debugger;
          console.log(res);
          this.loadData();
        });
      }

    })
  }
  render() {
    // let file = null;
    // if (this.state.file) {
    //   file = (
    //     <img alt="..." src={this.state.file} onClick={() => this.fileClickHandler("file")} style={{ "cursor": "pointer" }} className="avatar border-gray" />
    //   )
    // } else {
    //   file = (
    //     <img alt="..." src={this.state.profilePicture} onClick={() => this.fileClickHandler("file")} style={{ "cursor": "pointer" }} className="avatar border-gray" />
    //   )
    // }
    let options = [];
    if (this.state.user.gender === "Male") {
      let option = (
        <React.Fragment>
          <option>Select Gender</option>
          <option value="Male" selected>Male</option>
          <option value="Female">Female</option>
        </React.Fragment>
      );
      options.push(option);
    } else if (this.state.user.gender === "Female") {
      let option = (
        <React.Fragment>
          <option>Select Gender</option>
          <option value="Male">Male</option>
          <option value="Female" selected>Female</option>
        </React.Fragment>
      );
      options.push(option);
    } else {
      let option = (
        <React.Fragment>
          <option>Select Gender</option>
          <option value="Male">Male</option>
          <option value="Female">Female</option>
        </React.Fragment>
      );
      options.push(option);
    }
    return (
      <>
        <PanelHeader size="sm" />
        <div className="content">
          <Form>
            <Row>
              <Col md="4">
                <Row>
                  <Card className="card-user">
                    <div className="image">
                      <img alt="..." src={require("assets/img/bg5.jpg")} />
                    </div>
                    <CardBody>
                      <div className="author">
                        <a href="#pablo" onClick={e => e.preventDefault()}>
                          {
                            this.state.editable ? <img alt="..." src={this.state.profilePicture} onClick={() => this.fileClickHandler("file")} style={{ "cursor": "pointer" }} className="avatar border-gray" id="photo" /> : <img
                              alt="..."
                              className="avatar border-gray"
                              src={this.state.profilePicture}
                            />
                          }
                          <h5 className="title">{this.state.user.firstName + " " + this.state.user.lastName}</h5>
                        </a>
                      </div>
                      <Row>
                        <div style={{ "paddingLeft": "150px" }}><a href="#" id="editToolTip"><img src={require("assets/icons/edit-button.svg")} style={{ "width": "50px", "heigth": "50px", "cursor": "pointer" }} onClick={(event) => this.onEditHandler(event)} /></a></div>
                        <Tooltip placement="right" isOpen={this.state.tooltipOpen} target="editToolTip" toggle={this.toggle}>
                          Edit
                       </Tooltip>
                      </Row>
                    </CardBody>
                    <hr />
                  </Card>
                </Row>
              </Col>
              <Col md="8">
                <Card>
                  <CardHeader>
                    <h5 className="title"><img alt="..." src={require("assets/img/profile.gif")} style={{ "paddingLeft": "40%" }} /></h5>
                  </CardHeader>
                  <CardBody>
                    <Form>
                      <Row>
                        <Col className="px-1" md="3">
                          <FormGroup inline>
                            <CardHeader>
                              <h6>First Name</h6>
                            </CardHeader>
                          </FormGroup>
                        </Col>
                        <Col className="pl-1" md="4">
                          <FormGroup inline>
                            <CardHeader>
                              {

                                this.state.editable ? <Input type="text" name="firstName" value={this.state.user.firstName} onChange={(event) => this.imputChangeHandler(event)} /> : <Label>{this.state.user.firstName}</Label>

                              }
                            </CardHeader>
                          </FormGroup>
                        </Col>
                      </Row>
                      <Row>
                        <Col className="px-1" md="3">
                          <FormGroup inline>
                            <CardHeader>
                              <h6>Last Name</h6>
                            </CardHeader>
                          </FormGroup>
                        </Col>
                        <Col className="pl-1" md="4">
                          <FormGroup inline>
                            <CardHeader>
                              {
                                this.state.editable ? <Input type="text" name="lastName" value={this.state.user.lastName} onChange={(event) => this.imputChangeHandler(event)} /> : <Label>{this.state.user.lastName}</Label>
                              }
                            </CardHeader>
                          </FormGroup>
                        </Col>
                      </Row>
                      <Row>
                        <Col className="px-1" md="3">
                          <FormGroup inline>
                            <CardHeader>
                              <h6>Gender</h6>
                            </CardHeader>
                          </FormGroup>
                        </Col>
                        <Col className="pl-1" md="4">
                          <FormGroup inline>
                            <CardHeader>
                              {
                                this.state.editable ? <Input type="select" name="select" id="exampleSelect" name="gender" onChange={(event) => this.imputChangeHandler(event)}>
                                  {options}
                                </Input> : <Label>{this.state.user.gender}</Label>
                              }

                            </CardHeader>
                          </FormGroup>
                        </Col>
                      </Row>
                      <Row>
                        <Col className="px-1" md="3">
                          <FormGroup inline>
                            <CardHeader>
                              <h6>Dob</h6>
                            </CardHeader>
                          </FormGroup>
                        </Col>
                        <Col className="pl-1" md="4">
                          <FormGroup inline>
                            <CardHeader>
                              {
                                this.state.editable ? <Datepicker id="dob" name="dob" dateFormat="YYYY-MM-DD" value={this.state.user.dob}
                                  className="form-control" style={{ width: '100%' }} />
                                  : <Label>{this.state.user.dob}</Label>
                              }
                              <Input type="file" id="file" hidden onChange={(event) => this.fileChangeHandler(event)} />
                            </CardHeader>
                          </FormGroup>
                        </Col>
                      </Row>
                      <Row>
                        <Col className="px-1" md="3">
                          <FormGroup inline>
                            <CardHeader>
                              <h6>Email</h6>
                            </CardHeader>
                          </FormGroup>
                        </Col>
                        <Col className="pl-1" md="4">
                          <FormGroup inline>
                            <CardHeader>
                              <Label>{this.state.user.email}</Label>
                            </CardHeader>
                          </FormGroup>
                        </Col>
                      </Row>
                    </Form>
                    {
                      this.state.editable ? <Button onClick={(event) => this.formSubmitHandler(event)} color="primary">Submit</Button> : <div></div>
                    }
                  </CardBody>
                </Card>
              </Col>
            </Row>
          </Form>
        </div>
      </>
    );
  }
}

export default withErrorHandler(User, axios);
