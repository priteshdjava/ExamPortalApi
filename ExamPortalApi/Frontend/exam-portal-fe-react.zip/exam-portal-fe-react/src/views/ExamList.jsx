import React, { Component } from 'react'
import PanelHeader from "components/PanelHeader/PanelHeader.jsx";
import { Card, CardBody, Row, Col, CardTitle, CardHeader, Input, Button, FormGroup, Label } from 'reactstrap'
import { BEARER, ACCESS_TOKEN } from '../Constants/APIConstant'
import DataTable from 'react-data-table-component'
import axios from 'axios-auth';
import Modal from '../components/Modal/index'

class ExamList extends Component {
  constructor(props) {
    super(props);
    axios.defaults.headers.common['Authorization'] = BEARER + window.localStorage.getItem(ACCESS_TOKEN);
    this.state = {
      examlist: [],
      totalRows: null,
      currentpage: 0,
      rowsPerPage: 10,
      modalShow: false,
      name: {},
      editable: false
    }
  }
  componentDidMount() {
    debugger;
    this.loadExamlist(this.state.currentpage, this.state.rowsPerPage);
  }
  loadExamlist(pageNo, pageSize) {
    debugger;
    axios.get("/exam", {
      params: {
        pageNo: pageNo,
        pageSize: pageSize
      }
    }).then(res => {
      debugger;
      this.setState({ examlist: res.data.content, totalRows: res.data.totalElements, currentpage: res.data.pageable.pageNumber })
    }).catch(error => {
      console.log(error);
    });
  }
  handlePerRowsChange = (newPerPage, page) => {
    debugger;
    this.setState({ rowsPerPage: newPerPage })
    this.loadExamlist(page - 1, newPerPage);
  };
  handlePageChange = page => {
    debugger;
    this.loadExamlist(page - 1, this.state.rowsPerPage);
  };
  deleteHandler = (id) => {
    axios.delete("/exam/" + id + "").then(res => {
      if (res) {
        this.loadExamlist(this.state.currentpage, this.state.rowsPerPage);
      }
    })
  }

  editExamhamdler = (userObj) => {
    debugger;
    var examObjArr = this.state.examlist.filter(exam => {
      return userObj.id == exam.id
    });
    this.setState({
      name: {
        id: examObjArr[0].id,
        name: examObjArr[0].name
      },
      modalShow: true,
      editable: true
    })
    console.log(this.state);
  }
  addExamhandler = () => this.setState({ modalShow: true, editable: false })
  cancelModalhandler = () => this.setState({ modalShow: false, name: {} })
  inputChangeHandler = (event) => {
    debugger;
    this.setState({
      name: {
        ...this.state.name,
        [event.target.name]: event.target.value
      }
    })
    console.log(this.state);
  }
  onSaveExamhandler = () => {
    debugger;
    const createdBy = {
      id: window.localStorage.getItem("userId")
    }
    const examObj = {
      ...this.state.name,
      createdBy
    }
    axios.post("/exam", examObj).then(res => {
      debugger;
      if (res) {
        this.setState({ modalShow: false, name: {}, editable: false })
        this.loadExamlist(this.state.currentpage, this.state.rowsPerPage);
      }

    })
  }
  render() {
    const columns = [
      {
        name: 'Name',
        selector: 'name',
        sortable: true
      },
      {
        name: 'Created By',
        selector: (data) => {
          return data.createdBy.firstName + " " + data.createdBy.lastName
        },
        sortable: true
      },
      {
        name: 'Create Date',
        selector: 'createdDate',
        sortable: true
      },
      {
        name: 'Action',
        cell: row => {
          debugger
          return (
            <React.Fragment>
              <img src={require("assets/icons/edit-button.svg")} style={{ "width": "22px", "heigth": "22px", "cursor": "pointer" }} onClick={() => this.editExamhamdler(row)}></img>
              <img src={require("assets/icons/trash-outline.svg")} style={{ "width": "22px", "heigth": "22px", "cursor": "pointer" }} onClick={() => this.deleteHandler(row.id)} disables="true"></img>
            </React.Fragment>
          )
        }
      }
    ];
    const customStyles = {
      rows: {
        style: {
          minHeight: '40px', // override the row height
        }
      },
      headCells: {
        style: {
          paddingLeft: '5px', // override the cell padding for head cells
          paddingRight: '5px',
        },
      },
      cells: {
        style: {
          paddingLeft: '1px', // override the cell padding for data cells
          paddingRight: '1px',
        },
      },
    };
    return (
      <>
        <PanelHeader size="sm" />
        <div className="content">
          <Row>
            <Col>
              <Card>
                <CardBody>
                  <CardHeader>Exam List</CardHeader>
                  <CardBody>
                    <Row>
                      <Col md="3">
                        <Input type="text" placeholder="Search"></Input>
                      </Col>
                      <Col md="3">
                        <button className="primary" style={{ "backgroundColor": "transparent" }} onClick={this.addExamhandler}>Add Exam</button>
                      </Col>
                    </Row>
                  </CardBody>
                  <DataTable
                    columns={columns}
                    data={this.state.examlist}
                    pagination={true}
                    customStyles={customStyles}
                    keyField="id"
                    paginationServer={true}
                    paginationTotalRows={this.state.totalRows}
                    paginationDefaultPage={this.state.currentpage + 1}
                    onChangeRowsPerPage={this.handlePerRowsChange}
                    onChangePage={this.handlePageChange}

                  />
                  <Modal showCloseButton={false} show={this.state.modalShow}>
                    <Modal.Header>
                      <Modal.Title>
                        {this.state.editable ? "Edit Exam" : "Add Exam"}
                      </Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                      <FormGroup>
                        <Label>Exam Name</Label>
                        <Input type="text"
                          placeholder="name" name="name" onChange={(event) => this.inputChangeHandler(event)} value={this.state.name.name}
                        />
                      </FormGroup>
                    </Modal.Body>
                    <Modal.Footer>
                      <Button color="primary" onClick={this.onSaveExamhandler}>Save</Button>
                      <Button color="danger" onClick={this.cancelModalhandler}>Cancel</Button>
                    </Modal.Footer>
                  </Modal>
                </CardBody>
              </Card>
            </Col>
          </Row>
        </div>
      </>
    )
  }
}

export default ExamList