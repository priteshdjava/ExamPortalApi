import React, { Component } from "react";
import axios from '../../axios-auth';
import withErrorHandler from '../../hoc/withErrorHandler/withErrorHandler'
import './Signup.css'
class SignUp extends Component {
    constructor(props) {
        super(props);
        this.state = {
            formData: {
                email: '',
                password: '',
                confirmPassword: ''
            },
            passwordMatched: false,
            successMsg: ''
        }
    }

    onInputChangeHandler = (event) => {
        debugger;
        this.setState({
            formData: {
                ...this.state.formData,
                [event.target.name]: event.target.value
            }
        }, () => {
            if (this.state.formData.password === this.state.formData.confirmPassword && (this.state.formData.password && this.state.formData.confirmPassword && this.state.formData.email !== '')) {
                this.setState({ passwordMatched: true })
            } else {
                this.setState({ passwordMatched: false })
            }
        })
    }

    onLoginClick = (event) => {
        event.preventDefault();
        this.props.history.push("/sign-in");
    }
    onSubmitHandler = (event) => {
        debugger;
        event.preventDefault();
        axios.post("/signup", this.state.formData).then(res => {
            if (res && res.status === 200) {
                this.setState({
                    successMsg: res.data,
                    formData: {
                        email: '',
                        password: '',
                        confirmPassword: ''
                    }
                })
            }
        }).catch(error => {
            debugger;
            console.log(error)
        })
    }
    render() {
        return (
            <React.Fragment>
                <div className="center_div">
                    <h6 style={{ "textAlign": "center", "color": "green" }}>{this.state.successMsg}</h6>
                    <form onSubmit={this.onSubmitHandler}>
                        <h3>Sign Up</h3>
                        <div className="row">
                            <div className="col-md-6">
                                <div className="form-group">
                                    <label>Email</label>
                                    <input type="email" className="form-control" placeholder="Email" name="email" onChange={this.onInputChangeHandler} value={this.state.formData.email} />
                                </div>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-md-6">
                                <div className="form-group">
                                    <label>Password</label>
                                    <input type="password" className="form-control" placeholder="password" name="password" onChange={this.onInputChangeHandler} value={this.state.formData.password} />
                                </div>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-md-6">
                                <div className="form-group">
                                    <label>Confirm Password</label>
                                    <input type="Confirm Password" className="form-control" placeholder="Confirm Password" name="confirmPassword" onChange={this.onInputChangeHandler} value={this.state.formData.confirmPassword} />
                                </div>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-md-6">
                                <button type="submit" className="btn btn-primary btn-block" disabled={!this.state.passwordMatched}>Sign Up</button>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-md-6">
                                <p className="forgot-password text-right">
                                    Already registered <a href="" onClick={(event) => this.onLoginClick(event)}>sign in?</a>
                                </p>
                            </div>
                        </div>
                    </form>
                </div>
            </React.Fragment>
        );
    }
}

export default withErrorHandler(SignUp, axios)