import React, { Component } from "react";
import axios from '../../axios-auth';
import withErrorHandler from '../../hoc/withErrorHandler/withErrorHandler'
import { ACCESS_TOKEN, ROLE_ADMIN, ROLE_USER } from '../../Constants/APIConstant';
import { Redirect } from 'react-router-dom'
import './Login.css'
class Login extends Component {
    constructor(props) {
        super(props);
        this.state = {
            usernameOrEmail: '',
            password: '',
            userDashBoard: false,
            adminDashboard: false
        }
    }

    onSubmitHandler = (event) => {
        event.preventDefault();
        axios.post("/signin", this.state).then(res => {
            if (res && res.status === 200) {
                debugger;
                window.localStorage.setItem(ACCESS_TOKEN, res.data.accessToken);
                window.localStorage.setItem("userId", res.data.userId);
                axios.get("/user/find").then(res => {
                    if (res) {
                        if (res.data.role === ROLE_USER) {
                            this.setState({ userDashBoard: true })
                        } else {
                            this.setState({ adminDashboard: true })
                        }
                    }
                });
            }
        }).catch(error => {
            console.log(error);
        })
    }

    imputChangehandler = (event) => {
        this.setState({
            [event.target.name]: event.target.value
        })
    }
    onRegisterClick = () => {
        this.props.history.push("sign-up");
    }
    render() {
        let redirectPath = null;
        if (this.state.userDashBoard) {
            redirectPath = <Redirect to="/user/dashboard" />
        } if (this.state.adminDashboard) {
            redirectPath = <Redirect to="/admin/dashboard" />
        }
        return (
            <React.Fragment>
                {redirectPath}
                <div className="center_div">
                    <form onSubmit={this.onSubmitHandler}>
                        <h3>Sign In</h3>
                        <div className="row">
                            <div className="col-md-6">
                                <div className="form-group">
                                    <label>Email</label>
                                    <input type="email" className="form-control" placeholder="Enter email" name="usernameOrEmail" onChange={(event) => { this.imputChangehandler(event) }} />
                                </div>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-md-6">
                                <div className="form-group">
                                    <label>Password</label>
                                    <input type="password" className="form-control" placeholder="Enter password" name="password" onChange={(event) => { this.imputChangehandler(event) }} />
                                </div>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-md-6">
                                <div className="form-group">
                                    <div className="custom-control custom-checkbox">
                                        <input type="checkbox" className="custom-control-input" id="customCheck1" />
                                        <label className="custom-control-label" htmlFor="customCheck1">Remember me</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-md-6">
                                <div className="form-group">
                                    <button type="submit" className="btn btn-primary btn-block">Submit</button>
                                </div>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-md-6">
                                <p className="forgot-password text-right">
                                    Forgot <a href="#">password?</a>
                                </p>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-md-6">
                                <div className="form-group">
                                    <button type="button" className="btn btn-primary btn-block" onClick={this.onRegisterClick}>Register</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </React.Fragment>
        );
    }
}

export default withErrorHandler(Login, axios)