export const API_BASE_URL = 'http://localhost:8080/api';
export const ACCESS_TOKEN = 'accessToken';
export const BEARER = "Bearer ";
export const ROLE_ADMIN = "Admin";
export const ROLE_USER = "User"
