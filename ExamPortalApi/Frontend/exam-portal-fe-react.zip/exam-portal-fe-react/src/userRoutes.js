import UserDashboard from "views/UserDashboard.jsx";
import UserPage from "views/UserPage.jsx";

var dashRoutes = [
  {
    path: "/dashboard",
    name: "Dashboard",
    icon: "design_app",
    component: UserDashboard,
    layout: "/user"
  }
  ,
  {
    path: "/user-page",
    name: "User Profile",
    icon: "users_single-02",
    component: UserPage,
    layout: "/user"
  }
];
export default dashRoutes;
