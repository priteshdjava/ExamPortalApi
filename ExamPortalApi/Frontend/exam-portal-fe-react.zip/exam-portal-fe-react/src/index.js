import React from "react";
import ReactDOM from "react-dom";
import { createBrowserHistory } from "history";
import { Router, Route, Switch, Redirect } from "react-router-dom";

import "bootstrap/dist/css/bootstrap.css";
import "assets/scss/now-ui-dashboard.scss?v1.2.0";
import "assets/css/demo.css";
import Login from "./components/Login/login.component";
import Signup from './components/Signup/signup.component'
import AdminLayout from "layouts/Admin.jsx";
import UserLayout from 'layouts/User.jsx';
import AddUserPage from 'views/AddUserPage'
import { I18nextProvider } from 'react-i18next';
import i18n from './i18n';
const hist = createBrowserHistory();

ReactDOM.render(

  <Router history={hist}>
    <I18nextProvider i18n={i18n}>
      <Switch>
        <Route path="/" exact component={Login} />
        <Route path="/sign-up" exact component={Signup} />
        <Route path="/sign-in" exact component={Login} />
        <Route path="/admin/edit" exact component={AddUserPage}></Route>
        <Route path="/admin" render={props => <AdminLayout {...props} />} />
        <Route path="/user" render={props => <UserLayout {...props} />} />

      </Switch>
    </I18nextProvider>
  </Router>,
  // <I18nextProvider i18n={i18n}>
  document.getElementById("root")
  // </I18nextProvider>
);
