import pt from './default';
import en from './default.en';
import AdminDashboardPt from '../../views/AdminDashboard/locales/default.json'
import AdminDashbboardEn from '../../views/AdminDashboard/locales/default.en.json'

pt['pt-GU'].AdminDashboard = AdminDashboardPt['pt-GU'];
en['en'].AdminDashboard = AdminDashbboardEn['en'];


export {
  pt,
  en,
};
