import React, { Component } from 'react';
import { BEARER, ACCESS_TOKEN } from '../../Constants/APIConstant'
import Modal from '../../components/UI/Modal/Modal';
import Aux from '../Aux/Aux';

const withErrorHandler = (WrappedComponent, axios) => {
    return class extends Component {
        state = {
            error: null,
            errorMessage: ''
        }
       
        componentWillMount() {
            this.reqInterceptor = axios.interceptors.request.use(req => {
                debugger;
                req.headers.common['Authorization'] = BEARER + window.localStorage.getItem(ACCESS_TOKEN);
                this.setState({ errorMessage: '', error: null });
                return req;
            });
            this.resInterceptor = axios.interceptors.response.use(res => res, error => {
                let errorMessage = typeof error.response.data.message === "undefined" ? error.response.data : error.response.data.message
                this.setState({ errorMessage: errorMessage, error: error });
            });
        }

        componentWillUnmount() {
            axios.interceptors.request.eject(this.reqInterceptor);
            axios.interceptors.response.eject(this.resInterceptor);
        }

        errorConfirmedHandler = () => {
            this.setState({ error: null });
        }

        render() {
            return (
                <Aux>
                    <Modal
                        show={this.state.error}
                        modalClosed={this.errorConfirmedHandler}>
                        {this.state.error ? this.state.errorMessage : null}
                    </Modal>
                    <WrappedComponent {...this.props} />
                </Aux>
            );
        }
    }
}

export default withErrorHandler;