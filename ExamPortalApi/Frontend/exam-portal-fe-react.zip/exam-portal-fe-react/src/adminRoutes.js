import AdminDashboard from "views/AdminDashboard/AdminDashboard";
import UserPage from "views/UserPage.jsx";
import UserList from "views/UserList"
import ExamList from 'views/ExamList'
import QuestionList from 'views/QuestionList'

var dashRoutes = [
  {
    path: "/dashboard",
    name: "Dashboard",
    icon: "design_app",
    component: AdminDashboard,
    layout: "/admin"
  },
  {
    path: "/user-page",
    name: "User Profile",
    icon: "users_single-02",
    component: UserPage,
    layout: "/admin"
  },
  {
    path: "/user-list",
    name: "User List",
    icon: "users_single-02",
    component: UserList,
    layout: "/admin"
  },
  {
    path: "/exam-list",
    name: "Exam List",
    icon: "users_single-02",
    component: ExamList,
    layout: "/admin"
  },
  {
    path: "/question-list",
    name: "Question List",
    icon: "users_single-02",
    component: QuestionList,
    layout: "/admin"
  }
];
export default dashRoutes;
